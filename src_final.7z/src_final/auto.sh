#!/bin/bash

python train.py -c config_0.json
python train.py -c config_1.json
python train.py -c config_2.json
python train.py -c config_3.json